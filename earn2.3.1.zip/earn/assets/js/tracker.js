// TRACKER.JS logic for Blog Viewer Experience
let config = {
    minTime: 20, // 20 seconds
    minScroll: 50, // 50% depth
    postId: document.body.getAttribute('data-post-id'),
    ref: new URLSearchParams(window.location.search).get('ref')
};

if (config.ref) {
    let startTime = Date.now();
    let hasScrolled = false;

    window.addEventListener('scroll', () => {
        let scrollPct = (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
        if (scrollPct >= config.minScroll) hasScrolled = true;
    });

    // Send data only when user leaves or finishes
    window.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'hidden') {
            let timeSpent = Math.floor((Date.now() - startTime) / 1000);
            
            if (timeSpent >= config.minTime && hasScrolled) {
                navigator.sendBeacon('https://earn.accrachic.com/api/validate.php', JSON.stringify({
                    affiliate_id: config.ref,
                    post_id: config.postId,
                    duration: timeSpent,
                    device: /Mobi|Android/i.test(navigator.userAgent) ? 'mobile' : 'desktop'
                }));
            }
        }
    });
}
